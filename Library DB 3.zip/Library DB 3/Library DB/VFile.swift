//
//  VFile.swift
//  Library DB
//
//  Created by Komalpreet Kaur on 2017-11-07.
//  Copyright © 2017 Komalpreet Kaur. All rights reserved.
//

import Foundation

class  V {
static var bookname = [String]()
    static var bookcategory = [String]()
    static var bookrack = [String]()
    static var bookIsbn = [String]()
   
    
    
    static var category = [String]()
    static var rack = [String]()
    
    static var facultyname = [String]()
    static var facnumber = [String]()
    static var facid = [String]()
    
    static var stname = [String]()
    static var stnumber = [String]()
    static var stid = [String]()
    
    
    static var status=0
    
    static var librarianname = [String]()
    static var libusername = [String]()
    static var libpassword = [String]()
    
    static var finevalue = [String]()
    static var finestatus = [String]()
    static var fineduser = [String]()
    static var finedusertype = [String]()
    
    static var borrowedbook = [String]()
    static var personborrowed = [String]()
    static var date = [String]()
    static var borrowertype = [String]()
    


}

