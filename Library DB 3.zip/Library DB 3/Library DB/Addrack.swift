//
//  Addrack.swift
//  Library DB
//
//  Created by Komalpreet Kaur on 2017-11-07.
//  Copyright © 2017 Komalpreet Kaur. All rights reserved.
//

import Foundation

import UIKit

class Addrack: UIViewController ,UITextFieldDelegate{
    
    
    @IBAction func reset(_ sender: UIButton) {
        racknmbr.text = ""
    }
    @IBOutlet weak var racknmbr: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.racknmbr.delegate=self
       
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    @IBAction func add(_ sender: UIButton) {
        if(racknmbr.text! == ""){
            let alert = UIAlertController(title: "Error Message", message: "All feilds are  required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            V.rack.append(racknmbr.text!)
            print("Rack Added")
            racknmbr.text = ""
        }
    }
}
