//
//  libraryhome.swift
//  Library DB
//
//  Created by Komalpreet Kaur on 2017-11-07.
//  Copyright © 2017 Komalpreet Kaur. All rights reserved.
//

import Foundation
import UIKit

class Library: UIViewController {
    
    
    @IBAction func logout(_ sender: UIButton) {
        let lbhome: UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "viewc")as? ViewController)!
        self.navigationController?.pushViewController(lbhome, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }    
    
}


