//
//  addcategory.swift
//  Library DB
//
//  Created by Komalpreet Kaur on 2017-11-07.
//  Copyright © 2017 Komalpreet Kaur. All rights reserved.
//

import Foundation
import UIKit

class Addcategory: UIViewController ,UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @IBAction func reset(_ sender: UIButton) {
        
        categryname.text = "  "
    }
    
    
    @IBAction func doneAdd(_ sender: UIButton) {
        if(categryname.text! == ""){
            let alert = UIAlertController(title: "Error Message", message: "All feilds are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            V.category.append(categryname.text!)
            print("Category Added")
            categryname.text=""
        }
    }
    
    @IBOutlet weak var categryname: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.categryname.delegate=self
        
    }
    
    
}
