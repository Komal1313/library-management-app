//
//  ViewController.swift
//  Library DB
//
//  Created by Komalpreet Kaur on 2017-11-07.
//  Copyright © 2017 Komalpreet Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate{

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var userpass: UITextField!
    
    @IBAction func login(_ sender: UIButton) {
       
        if (username.text!=="" || userpass.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All feilds are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        else
        {
        var libuser = V.libusername
        var libpas = V.libpassword
           print(libpas)
            var cindex = ""
            for i in 0..<libuser.count{
                if (libuser[i] == username.text!){
                    cindex = String(i)
                break
                }
            }
            if (cindex == ""){
                let alert = UIAlertController(title: "Error Message", message: "Username or Password must be wrong", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }else{
                let ccindex = Int(cindex)
                
                if (libpas[ccindex!] == userpass.text!)
                {
                    let lbhome: UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "libhome")as? Library)!
                    self.navigationController?.pushViewController(lbhome, animated: true)
                    
                }
                else
                {
                    let alert = UIAlertController(title: "Error Message", message: "Username or Password must be wrong", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)

                }
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.username.delegate=self
        navigationItem.hidesBackButton=true
        self.userpass.delegate=self
        // Do any additional setup after loading the view, typically from a nib.
        
        if(V.status==0){
        V.bookname=["Science","Beauty beast","Harry potter","belive in God","World War  2"]
        V.category = ["Science","Story Books","History"]
        V.rack = ["R1","R2","R3"]
        V.bookIsbn = ["11","12","13","14","15"]
        V.bookcategory = ["0","1","1","2","0"]
        V.bookrack = ["0","1","2","2","0"]
        
        V.facultyname = ["KIRAN", "KOMAL" ,"PAWAN" ,"PRABH" ,"JOT"]
        V.facid = ["f1","f2","f3","f4","f5"]
        V.facnumber = ["6478527485","6472356352","6477899676","6458794561","7894561472"]
        
        
     V.stname = ["S1","S2","S3","S4","S5"]
     V.stid = ["21","22","23","24","25"]
        V.stnumber = ["6478527485","6472356352","6477899676","6458794561","7894561472"]
        
        V.librarianname = ["KOMALPREET"]
        V.libusername = ["komal"]
        V.libpassword = ["kc"]
        
        V.finevalue = ["23","10","235"]
        V.finestatus = ["0","1","1"]
        V.fineduser = ["4","2","0"]
        V.finedusertype = ["1","0","1"]
        V.status=1
    }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

