//
//  AddUser.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/8/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class AddUser: UIViewController, UIPickerViewDataSource,UIPickerViewDelegate , UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    @IBOutlet weak var selectorUIView: UIView!
    
    @IBAction func userTypeAction(_ sender: UIButton) {
        self.selectorUIView.isHidden = false;
    }
    @IBAction func doneact(_ sender: UIButton) {
        if(self.userTypeButton.titleLabel?.text == "==Select User=="){
            let alert = UIAlertController(title: "Error Message", message: "Please select user type.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return;
        }
        self.selectorUIView.isHidden = true;
        
    }
    @IBOutlet weak var userTypeButton: UIButton!
    @IBOutlet weak var phone: UITextField!
    var typemenu=["Faculty","Student"]
    @IBOutlet weak var dropdown: UIPickerView!
    @IBOutlet weak var uid: UITextField!
    @IBOutlet weak var name: UITextField!
    
    @IBAction func generateid(_ sender: UIButton) {
        let utype=self.userTypeButton.titleLabel?.text
        
        if(name.text!=="" || phone.text!=="" || utype=="" ){
            let alert = UIAlertController(title: "Error Message", message: "All feilds are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            var intial=""
            if(utype=="Faculty"){
                intial="F"
            }else if(utype=="Student"){
                intial="S"
            }
            var uname=name.text!
            var mob=phone.text!
            uname=uname.substring(from:uname.index(uname.endIndex, offsetBy: -3))
            mob=mob.substring(from:mob.index(mob.endIndex, offsetBy: -3))
            var mainEid=intial+uname+mob
            print(intial)
            print(uname)
            print(mob)
            uid.text=mainEid
        }
    }
    @IBAction func submit(_ sender: UIButton) {
        let utype=self.userTypeButton.titleLabel?.text
        
        if(name.text!=="" || phone.text!=="" ){
            let alert = UIAlertController(title: "Error Message", message: "All feilds are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if(uid.text!==""){
            print("Please generate Id By Clicking on Genearate ID button")
        }else{
            if(utype=="Faculty"){
                V.facultyname.append(name.text!)
                V.facnumber.append(phone.text!)
                V.facid.append(uid.text!)
            }else if(utype=="Student"){
                V.stname.append(name.text!)
                V.stnumber.append(phone.text!)
                V.stid.append(uid.text!)
                print(V.stname)
                print(V.stid)
            }
        }
        
    }
    @IBAction func reset(_ sender: UIButton) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.userTypeButton.layer.cornerRadius = 6.0;
        self.userTypeButton.layer.borderColor = UIColor.lightGray.cgColor;
        self.userTypeButton.layer.borderWidth = 0.5;
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
        
    }
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return typemenu.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typemenu[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.view.endEditing(true);
        self.userTypeButton.setTitle(self.typemenu[row], for: .normal)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true;
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        
    }
    
}

/*
 @IBAction func submit(_ sender: UIButton) {
 if(name.text!=="" || phone.text!=="" ){
 print("All Fields are required")
 }else if(uid.text!==""){
 print("Please generate Id By Clicking on Genearate ID button")
 }else{
 
 }
 
 }
 */

